<?php
// Heading 
$_['heading_title']  = 'تغییر رمز عبور';

// Text
$_['text_account']   = 'حساب';
$_['text_password']  = 'رمز عبور';
$_['text_success']   = 'نتيجه : رمز عبور شما با موفقيت به روزرسانی شد!';

// Entry
$_['entry_password'] = 'رمز عبور:';
$_['entry_confirm']  = 'تکرار رمز عبور:';

// Error
$_['error_password'] = 'رمز عبور باید بین 4 تا 20 کاراکتر باشد!';
$_['error_confirm']  = 'تکرار رمز عبور با رمز عبور مطابقت ندارد!';