<?php
// Heading 
$_['heading_title']      = 'امتیازهای شما';

// Column
$_['column_date_added']  = 'تاریخ اضافه شدن';
$_['column_description'] = 'توضیحات';
$_['column_points']      = 'امتیاز';

// Text
$_['text_account']       = 'حساب';
$_['text_reward']        = 'امتیاز';
$_['text_total']         = 'جمع کل امتیاز های شما:';
$_['text_empty']         = 'شما هیچ امتیازی ندارید!';