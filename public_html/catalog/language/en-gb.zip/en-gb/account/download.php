<?php
// Heading 
$_['heading_title']   = 'دانلودها';

// Text
$_['text_account']    = 'حساب';
$_['text_downloads']  = 'دانلودها';
$_['text_empty']        = 'شما هیچ سفارش برای دانلود ندارید!';

// Column
$_['column_order_id']   = 'کد سفارش';
$_['column_name']       = 'نام';
$_['column_size']       = 'سایز';
$_['column_date_added'] = 'تاریخ افزودن';