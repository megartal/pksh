<?php
// Heading
$_['heading_title'] = 'اطلاعات';

// Text
$_['text_contact']  = 'تماس با ما';
$_['text_sitemap']  = 'نقشه سایت';