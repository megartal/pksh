<?php
// Heading
$_['heading_title'] = 'فروشگاه را انتخاب کنید';

// Text
$_['text_default']  = 'پیش فرض';
$_['text_store']    = 'لطفا فروشگاه مورد نظر را انتخاب کنید';