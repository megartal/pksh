<?php
// Heading
$_['heading_title'] = 'پیشنهاد های ویژه';

// Text
$_['text_tax']      = 'Ex Tax:';