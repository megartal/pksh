<?php
// Heading
$_['heading_title'] = 'آخرین ها';

// Text
$_['text_tax']      = 'Ex Tax:';