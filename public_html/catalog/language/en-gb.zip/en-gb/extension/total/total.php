<?php
// Text
$_['text_total'] = 'جمع نهایی';