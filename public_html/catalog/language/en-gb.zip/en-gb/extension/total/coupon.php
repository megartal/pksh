<?php
// Heading
$_['heading_title'] = 'کد تخفیف';

// Text
$_['text_coupon']   = 'تخفیف (%s)';
$_['text_success']  = 'نتیجه: کد تخفیف شما اعمال شد!';

// Entry
$_['entry_coupon']  = 'کد تخفیف خود را وارد کنید';

// Error
$_['error_coupon']  = 'هشدار: کد تخفیف شما معتبر نیست';
$_['error_empty']   = 'هشدار: لطفا کد تخفیف خود را وارد کنید';