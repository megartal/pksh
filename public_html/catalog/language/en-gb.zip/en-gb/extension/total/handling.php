<?php
// Text
$_['text_handling'] = 'هزینه پیگیری';