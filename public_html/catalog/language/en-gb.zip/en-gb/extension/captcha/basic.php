<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'لطفا کد زیر را وارد کنید';

// Error
$_['error_captcha'] = 'کد وارد شده صحیح نمی باشد';