<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'لطفا اعتبار سنجی زیر را تکمیل کنید';

// Error
$_['error_captcha'] = 'اعتبار سنجی به درستی انجام نشد!';