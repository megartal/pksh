<?php
// Text
$_['text_success'] = 'نتیجه: نشست (Session) رابط برنامه نویسی نرم افزار (API) با موفقیت آغاز شده است!';

// Error
$_['error_key']    = 'Warning: Incorrect API Key!';
$_['error_ip']     = 'Warning: Your IP %s is not allowed to access this API!';