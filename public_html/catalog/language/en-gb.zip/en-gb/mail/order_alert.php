<?php
// Text
$_['text_subject']      = '%s - سفارش %s';
$_['text_received']     = 'شما یک سفارش دریافت کردید';
$_['text_order_id']     = 'کد سفارش:';
$_['text_date_added']   = 'تاریخ افزودن:';
$_['text_order_status'] = 'وضعیت سفارش:';
$_['text_product']      = 'محصولات';
$_['text_total']        = 'مجموع';
$_['text_comment']      = 'نظرات برای سفارش شما:';
