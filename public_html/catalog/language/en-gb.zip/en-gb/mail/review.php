<?php
// Text
$_['text_subject']	= '%s - نظرات کالا';
$_['text_waiting']	= 'یک نظر جدید برای کالا در انتظار تایید شما می باشد.';
$_['text_product']	= 'کالا: %s';
$_['text_reviewer']	= 'نظر دهنده: %s';
$_['text_rating']	= 'امتیاز: %s';
$_['text_review']	= 'متن نظر:';
?>