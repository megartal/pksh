<?php
// Text
$_['text_all'] = 'نمایش دادن همه';