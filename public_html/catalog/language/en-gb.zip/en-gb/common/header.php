<?php
// Text
$_['text_home']          = 'صفحه اصلی';
$_['text_wishlist']      = 'لیست دلخواه (%s)';
$_['text_shopping_cart'] = 'سبد خرید';
$_['text_category']      = 'دسته بندی ها';
$_['text_account']       = 'حساب کاربری من';
$_['text_register']      = 'ثبت نام';
$_['text_login']         = 'ورود';
$_['text_order']         = 'تاریخچه سفارش ها';
$_['text_transaction']   = 'تراکنش ها';
$_['text_download']      = 'دانلودها';
$_['text_logout']        = 'خروج';
$_['text_checkout']      = 'ثبت سفارش';
$_['text_search']        = 'جستجو';
$_['text_all']           = 'نمایش تمام';
?>