<?php
// Text
$_['text_items']     = '%s کالا - %s';
$_['text_no_results']     = 'سبد خرید شما خالی است!';
$_['text_cart']      = 'مشاهده سبد';
$_['text_checkout']  = 'ثبت سفارش';
$_['text_recurring'] = 'پروفایل پرداخت';
?>