<?php
// Text
$_['text_information']  = 'اطلاعات';
$_['text_service']      = 'خدمات مشتریان';
$_['text_extra']        = 'ضمایم';
$_['text_contact']      = 'تماس با ما';
$_['text_return']       = 'بازگشتی ها';
$_['text_sitemap']      = 'نقشه سایت';
$_['text_manufacturer'] = 'برندها';
$_['text_voucher']      = 'کدهای تخفیف';
$_['text_affiliate']    = 'بازاریاب ها';
$_['text_special']      = 'محصولات ویژه';
$_['text_account']      = 'حساب کاربری من';
$_['text_order']        = 'تاریخچه سفارش ها';
$_['text_wishlist']     = 'لیست دلخواه';
$_['text_newsletter']   = 'خبرنامه';
$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">Pakhshplus</a><br /> %s &copy; %s';